#define QT_FEATURE_networkinterface 1
#define QT_FEATURE_bearermanagement 1
#define QT_FEATURE_dnslookup 1
#define QT_FEATURE_securetransport 1
#define QT_SECURETRANSPORT true
#define QT_NO_OPENSSL true
#define QT_FEATURE_dtls -1
#define QT_FEATURE_ftp 1
#define QT_FEATURE_gssapi 1
#define QT_FEATURE_http 1
#define QT_FEATURE_localserver 1
#define QT_FEATURE_networkdiskcache 1
#define QT_FEATURE_networkproxy 1
#define QT_FEATURE_opensslv11 -1
#define QT_FEATURE_ocsp -1
#define QT_FEATURE_schannel -1
#define QT_FEATURE_sctp -1
#define QT_NO_SCTP 
#define QT_FEATURE_socks5 1
#define QT_FEATURE_ssl 1
#define QT_FEATURE_sspi -1
#define QT_NO_SSPI 
#define QT_FEATURE_udpsocket 1
